# SheSync papers – reproducibility scripts

These scripts produce every number reported in the two papers. They run against the
SheSync source code (`src/`) from the project repository.

## Paper 1 (ICOFE'26) – cycle-forecast optimisation
* `sim_a.py` – simulation testbed (1,000 users, 3 cohorts, stationary and drifting regimes, fixed seed),
  exact Python port of `calculateCyclePredictionAndPrecautions`, grid search, shrinkage prior and
  confidence recalibration. Run `python3 sim_a.py` → `results_a.json` and `validate_in.json`.
* `validate.js` – runs the real TypeScript engine on `validate_in.json`; comparing with the Python port
  gave 2,400 / 2,400 exact matches.

## Paper 2 (ICNQC) – rule-level verification
* `build.js` + `entry.ts` + `stubs/` – bundle the production Zustand store with esbuild
  (only the Supabase and PDF services are stubbed): `npm install esbuild@0.24 && node build.js`.
* `eval_b.js` – enumerates all 19,800 input states and checks properties P1–P5 → `results_b.json`.
* `refined_rules.patch` – the five one-line refinements evaluated in the paper.
  To reproduce the "refined" column: apply the patch to a copy of `src/store/useAppStore.ts`,
  bundle it, then run `CORE=./shesync_hardened.cjs OUT=results_b_hardened.json node eval_b_configurable.js`.

Environment used: Python 3.13 + NumPy, Node.js v22, Intel Xeon 2.1 GHz.
