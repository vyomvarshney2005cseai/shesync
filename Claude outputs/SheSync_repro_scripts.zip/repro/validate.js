const m=require('./shesync_core.cjs');const fs=require('fs');
const val=JSON.parse(fs.readFileSync('validate_in.json'));const out=[];
for(const v of val){const cycles=v.hist.map((l,i)=>({id:'c'+i,cycleNumber:i+1,daysAgo:i===0?10:undefined,lengthDays:l,periodDurationDays:5}));
 const ans=v.q1?{q1:v.q1}:{};const r=m.calculateCyclePredictionAndPrecautions(v.h,cycles,ans,4,'none');
 out.push([r.predictedCycleLength,r.regularityStatus,r.confidencePercentage,r.cycleVarianceDays]);}
fs.writeFileSync('validate_ts.json',JSON.stringify(out));console.log(out.length);
