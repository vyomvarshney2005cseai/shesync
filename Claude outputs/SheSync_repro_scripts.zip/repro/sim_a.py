"""
Paper A evaluation: cycle-length forecasting in SheSync.
Reproducible simulation (seed fixed). Cohort parameters are informed by published
app-based cycle statistics (Bull 2019; Soumpasis 2020; Grieger & Norman 2020).
"""
import json, math, itertools, sys
import numpy as np

RNG = np.random.default_rng(20261103)
T = 13            # cycles generated per simulated user
H = 4             # history window used by the deployed engine (weights defined for 4 cycles)

def jsround(x):   # JavaScript Math.round semantics
    return math.floor(x + 0.5)

# ---------------------------------------------------------------- cohorts
COHORTS = {
    # name: (n_users, mu_mean, mu_sd, mu_lo, mu_hi, sig_lo, sig_hi, p_disrupt, drift_sd)
    'A': (400, 28.8, 1.6, 25, 32, 0.8, 2.0, 0.03, 0.6),
    'B': (400, 30.0, 2.2, 25, 35, 2.5, 5.0, 0.10, 1.0),
    'C': (200, 42.0, 5.0, 36, 55, 4.5, 9.0, 0.12, 1.5),
}

def gen_users(drift: bool):
    users = []
    for c, (n, mm, ms, lo, hi, slo, shi, pd, dsd) in COHORTS.items():
        for _ in range(n):
            mu = float(np.clip(RNG.normal(mm, ms), lo, hi))
            sig = float(RNG.uniform(slo, shi))
            m = mu
            L = []
            for t in range(T):
                if drift and t > 0:
                    m += RNG.normal(0, dsd)
                    m = float(np.clip(m, 21 if c != 'C' else 33, 40 if c != 'C' else 62))
                x = m + RNG.normal(0, sig)
                if RNG.random() < pd:
                    x += RNG.integers(5, 15)
                L.append(int(np.clip(round(x), 15, 90)))
            # questionnaire answer q1 chosen from the user's own profile (self-report)
            if mu > 35: q1 = 'q1_opt3'
            elif sig > 3.5: q1 = 'q1_opt4'
            elif mu < 24: q1 = 'q1_opt2'
            else: q1 = 'q1_opt1'
            users.append({'cohort': c, 'mu': mu, 'sig': sig, 'L': L, 'q1': q1})
    return users

# ---------------------------------------------------------------- deployed engine (exact port)
def deployed(hist, q1=None, remembered=4):
    """hist: most-recent-first list of past cycle lengths. Port of calculateCyclePredictionAndPrecautions."""
    eff = 1 if remembered == -1 else max(1, remembered)
    valid = hist[:eff] if len(hist) else [28]
    w = [3.0, 2.0, 1.5, 1.0]
    ws = sum((l or 28) * (w[i] if i < 4 else 1.0) for i, l in enumerate(valid))
    tw = sum((w[i] if i < 4 else 1.0) for i in range(len(valid)))
    avg = jsround(ws / tw) or 28
    if q1 == 'q1_opt2': avg = min(avg, 23)
    elif q1 == 'q1_opt3': avg = max(avg, 38)
    elif q1 == 'q1_opt4': avg = max(avg, 35)
    elif q1 == 'q1_opt5': avg = max(avg, 45)
    if len(valid) > 1:
        ssd = sum(((l or 28) - avg) ** 2 for l in valid)
        var = jsround(math.sqrt(ssd / len(valid)) * 10) / 10
    elif q1 in ('q1_opt4', 'q1_opt5') or remembered == -1: var = 7.5
    elif q1 == 'q1_opt3': var = 4.2
    else: var = 1.2
    cv = jsround(var / max(20, avg) * 100)
    if (q1 in ('q1_opt4', 'q1_opt5') or remembered == -1 or var > 5.5 or cv > 18 or avg > 36 or avg < 21):
        status, conf = 'irregular_pcos', max(65, 72 - jsround(var * 1.2))
    elif q1 == 'q1_opt3' or var > 2.5 or cv > 9:
        status, conf = 'moderate_variance', max(76, 86 - jsround(var * 1.5))
    else:
        status, conf = 'regular', min(97, 91 + min(len(valid) * 2, 6))
    return avg, status, conf, var

# ---------------------------------------------------------------- forecasting methods
def weighted(hist, w):
    k = min(len(hist), len(w))
    ws = sum(hist[i] * w[i] for i in range(k)); tw = sum(w[:k])
    return ws / tw if tw > 0 else hist[0]

def ses(hist, alpha):
    seq = list(reversed(hist[:H]))
    s = seq[0]
    for x in seq[1:]: s = alpha * x + (1 - alpha) * s
    return s

PRIOR = {'q1_opt1': 29.0, 'q1_opt2': 23.0, 'q1_opt3': 40.0, 'q1_opt4': 31.0, 'q1_opt5': 45.0, None: 29.3}

def shrink(hist, w, q1, tau):
    n = min(len(hist), len(w))
    return (n * weighted(hist, w) + tau * PRIOR[q1]) / (n + tau)

# ---------------------------------------------------------------- evaluation helpers
def tasks(users, h):
    """(user, history most-recent-first of length h, target) for t >= h."""
    out = []
    for u in users:
        L = u['L']
        for t in range(max(h, H), T):          # same targets for every h -> comparable
            hist = list(reversed(L[t - h:t]))
            out.append((u, hist, L[t]))
    return out

def metrics(err):
    e = np.asarray(err, dtype=float); a = np.abs(e)
    return {'MAE': float(a.mean()), 'RMSE': float(np.sqrt((e ** 2).mean())), 'bias': float(e.mean()),
            'within2': float((a <= 2).mean() * 100), 'within3': float((a <= 3).mean() * 100), 'n': int(len(e))}

def evaluate(tk, fn):
    return [jsround(fn(u, hist)) - y for (u, hist, y) in tk]

def split(users):
    idx = np.arange(len(users)); RNG.shuffle(idx)
    half = len(users) // 2
    tr = [users[i] for i in idx[:half]]; te = [users[i] for i in idx[half:]]
    return tr, te

def grid_weights(tk):
    vals = [0.0, 0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 3.5, 4.0]
    best = None
    ys = np.array([y for (_, _, y) in tk], dtype=float)
    Hm = np.array([h[:4] for (_, h, _) in tk], dtype=float)
    for w in itertools.product(vals, repeat=4):
        if w[0] == 0: continue
        W = np.array(w); pred = np.floor(Hm @ W / W.sum() + 0.5)
        mae = np.abs(pred - ys).mean()
        if best is None or mae < best[0] - 1e-12: best = (mae, w)
    s = sum(best[1]); return [round(x / s, 3) for x in best[1]], best[0]

def run(drift):
    users = gen_users(drift)
    tr, te = split(users)
    tk_tr, tk_te = tasks(tr, H), tasks(te, H)
    # tune baselines on train
    alphas = np.round(np.arange(0.05, 0.96, 0.05), 2)
    a_best = min(alphas, key=lambda a: np.abs(evaluate(tk_tr, lambda u, h: ses(h, a))).mean())
    w_opt, _ = grid_weights(tk_tr)
    taus = [0, 0.25, 0.5, 1, 1.5, 2, 3, 4]
    cold_tr = tasks(tr, 1) + tasks(tr, 2)
    tau_best = min(taus, key=lambda t: np.abs(evaluate(cold_tr, lambda u, h: shrink(h, w_opt, u['q1'], t))).mean())
    W0 = [3.0, 2.0, 1.5, 1.0]
    methods = {
        'Naive 28-day': lambda u, h: 28,
        'Last cycle': lambda u, h: h[0],
        'Mean of last 3': lambda u, h: float(np.mean(h[:3])),
        'Median of last 4': lambda u, h: float(np.median(h[:4])),
        f'SES (alpha={a_best})': lambda u, h: ses(h, a_best),
        'SheSync weights only': lambda u, h: weighted(h, W0),
        'SheSync deployed (weights+q1 floor)': lambda u, h: deployed(h, u['q1'], 4)[0],
        'Optimised weights': lambda u, h: weighted(h, w_opt),
        f'Optimised + shrinkage (tau={tau_best})': lambda u, h: shrink(h, w_opt, u['q1'], tau_best),
    }
    res = {}
    for name, fn in methods.items():
        res[name] = {'All': metrics(evaluate(tk_te, fn))}
        for c in COHORTS:
            res[name][c] = metrics(evaluate([x for x in tk_te if x[0]['cohort'] == c], fn))
    # history length (cold start) on test
    hist_len = {}
    for h in [1, 2, 3, 4]:
        tk = tasks(te, h)
        hist_len[h] = {
            'Naive 28-day': metrics(evaluate(tk, lambda u, hh: 28))['MAE'],
            'SheSync deployed': metrics(evaluate(tk, lambda u, hh: deployed(hh, u['q1'], h)[0]))['MAE'],
            'Optimised + shrinkage': metrics(evaluate(tk, lambda u, hh: shrink(hh, w_opt, u['q1'], tau_best)))['MAE'],
        }
    # q1-floor effect: users answering q1_opt4 (irregular) in test
    tk4 = [x for x in tk_te if x[0]['q1'] == 'q1_opt4']
    floor_effect = {'n_users_opt4': len({id(x[0]) for x in tk4}),
                    'MAE_weights_only': metrics(evaluate(tk4, lambda u, h: weighted(h, W0)))['MAE'],
                    'MAE_with_floor': metrics(evaluate(tk4, lambda u, h: deployed(h, u['q1'], 4)[0]))['MAE'],
                    'bias_with_floor': metrics(evaluate(tk4, lambda u, h: deployed(h, u['q1'], 4)[0]))['bias'],
                    'mean_true_len': float(np.mean([y for (_, _, y) in tk4]))}
    # confidence calibration of the deployed engine (test)
    calib = {}
    rows = []
    for (u, h, y) in tk_te:
        p, st, cf, var = deployed(h, u['q1'], 4)
        rows.append((st, cf, abs(p - y), var))
    for st in ['regular', 'moderate_variance', 'irregular_pcos']:
        r = [x for x in rows if x[0] == st]
        if r:
            calib[st] = {'n': len(r), 'stated_conf_mean': float(np.mean([x[1] for x in r])),
                         'hit2': float(np.mean([x[2] <= 2 for x in r]) * 100),
                         'hit3': float(np.mean([x[2] <= 3 for x in r]) * 100)}
    # calibrated confidence: empirical P(|err|<=2) as a function of observed SD, fitted on TRAIN by binning
    tr_rows = []
    for (u, h, y) in tk_tr:
        p, st, cf, var = deployed(h, u['q1'], 4)
        tr_rows.append((var, abs(p - y) <= 2))
    bins = [0, 1, 2, 3, 4, 6, 8, 100]
    table = []
    for lo, hi in zip(bins[:-1], bins[1:]):
        r = [hit for (v, hit) in tr_rows if lo <= v < hi]
        table.append((lo, hi, float(np.mean(r) * 100) if r else None, len(r)))
    def calibrated_conf(var):
        for lo, hi, pct, n in table:
            if lo <= var < hi and pct is not None: return pct
        return 50.0
    def ece(pairs):
        # pairs (stated%, hit bool) -> expected calibration error (10 bins)
        pairs = np.array(pairs, dtype=float); tot = 0.0
        for lo in range(0, 100, 10):
            m = (pairs[:, 0] >= lo) & (pairs[:, 0] < lo + 10 if lo < 90 else pairs[:, 0] <= 100)
            if m.sum(): tot += m.sum() * abs(pairs[m, 0].mean() - pairs[m, 1].mean() * 100)
        return tot / len(pairs)
    stated = [(x[1], x[2] <= 2) for x in rows]
    recal = [(calibrated_conf(x[3]), x[2] <= 2) for x in rows]
    calib_summary = {'ECE_stated': ece(stated), 'ECE_recalibrated': ece(recal), 'bins': table}
    # plausibility of generated data
    allL = np.array([l for u in users for l in u['L']])
    pl = {'mean_len': float(allL.mean()), 'sd_len': float(allL.std()),
          'pct_21_35': float(((allL >= 21) & (allL <= 35)).mean() * 100),
          'pct_users_range_ge5_first6': float(np.mean([max(u['L'][:6]) - min(u['L'][:6]) >= 5 for u in users]) * 100),
          'pct_users_range_ge5_AB': float(np.mean([max(u['L'][:6]) - min(u['L'][:6]) >= 5 for u in users if u['cohort'] != 'C']) * 100),
          'n_users': len(users), 'n_test_predictions': len(tk_te)}
    ed = evaluate(tk_te, methods['SheSync deployed (weights+q1 floor)'])
    eo = evaluate(tk_te, methods[f'Optimised + shrinkage (tau={tau_best})'])
    uid = [id(x[0]) for x in tk_te]; remap = {v: i for i, v in enumerate(dict.fromkeys(uid))}
    paired = [[remap[u], a, b] for u, a, b in zip(uid, ed, eo)]
    return {'paired': paired, 'alpha': float(a_best), 'w_opt': w_opt, 'tau': tau_best, 'results': res, 'hist_len': hist_len,
            'floor_effect': floor_effect, 'calibration': calib, 'calib_summary': calib_summary, 'plausibility': pl}, users

if __name__ == '__main__':
    out = {}
    out['stationary'], users_s = run(drift=False)
    out['drift'], users_d = run(drift=True)
    json.dump(out, open('results_a.json', 'w'), indent=1)
    # export random histories for exact-match validation against the TypeScript engine
    val = []
    for u in users_d[:600]:
        for h in [1, 2, 3, 4]:
            val.append({'hist': list(reversed(u['L'][4 - h + 5:9])) if False else u['L'][9 - h:9][::-1], 'q1': u['q1'], 'h': h})
    json.dump(val, open('validate_in.json', 'w'))
    print(json.dumps({k: {'w_opt': v['w_opt'], 'alpha': v['alpha'], 'tau': v['tau']} for k, v in out.items()}))
