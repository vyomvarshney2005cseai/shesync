const esbuild=require('esbuild'),path=require('path');
const SRC=path.resolve('../repo/src');
const alias={name:'alias',setup(b){
 b.onResolve({filter:/^@\//},a=>{
  if(a.path==='@/lib/supabaseService')return{path:path.resolve('stubs/supabaseService.ts')};
  if(a.path==='@/lib/pdfReportService')return{path:path.resolve('stubs/pdf.ts')};
  const base=path.join(SRC,a.path.slice(2));
  for(const ext of ['.ts','.tsx','/index.ts']){const f=base+ext;if(require('fs').existsSync(f))return{path:f};}
  return{path:base};});}};
esbuild.build({entryPoints:['entry.ts'],bundle:true,platform:'node',format:'cjs',outfile:'shesync_core.cjs',plugins:[alias],
 nodePaths:[path.resolve('../repo/node_modules')],logLevel:'warning'}).then(()=>console.log('built'));
