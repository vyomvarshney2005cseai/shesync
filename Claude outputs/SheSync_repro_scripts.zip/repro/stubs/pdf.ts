export async function generateAndDownloadClinicalPDF(_: any) { return null; }
