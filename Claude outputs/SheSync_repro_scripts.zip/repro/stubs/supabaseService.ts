export const saveDailyLogToSupabase = async (_: any) => null;
export const saveCycleToSupabase = async (_: any) => null;
export const signOutSupabase = async () => null;
