// Paper B evaluation: exhaustive verification of SheSync's rule-based analytics engine,
// executed on the real TypeScript store (bundled with esbuild; Supabase calls stubbed).
const m = require('./shesync_core.cjs');
const fs = require('fs');
const S = m.useAppStore;

const PROFILES = {
  'No assessment': {},
  'PCOS-type': { q1: 'q1_opt3', q2: 'q2_opt2', q3: 'q3_opt2', q4: 'q4_opt2', q5: 'q5_opt2', q6: 'q6_opt2', q7: 'q7_opt2', q8: 'q8_opt2', q9: 'q9_opt3', q10: 'q10_opt1' },
  'PMDD-type': { q1: 'q1_opt1', q2: 'q2_opt2', q3: 'q3_opt3', q4: 'q4_opt2', q5: 'q5_opt3', q6: 'q6_opt4', q7: 'q7_opt4', q8: 'q8_opt3', q9: 'q9_opt2', q10: 'q10_opt2' },
  'High-stress type': { q1: 'q1_opt1', q2: 'q2_opt2', q3: 'q3_opt4', q4: 'q4_opt4', q5: 'q5_opt4', q6: 'q6_opt3', q7: 'q7_opt2', q8: 'q8_opt1', q9: 'q9_opt4', q10: 'q10_opt3' },
  'Low-risk type': { q1: 'q1_opt1', q2: 'q2_opt1', q3: 'q3_opt1', q4: 'q4_opt1', q5: 'q5_opt1', q6: 'q6_opt1', q7: 'q7_opt1', q8: 'q8_opt1', q9: 'q9_opt1', q10: 'q10_opt4' },
};
const FLOWS = ['none', 'spotting', 'light', 'moderate', 'heavy', 'severe'];
const ENERGY = ['low', 'restorative', 'moderate', 'high'];
const SENS = ['gentle', 'balanced', 'dynamic'];

const init = JSON.parse(JSON.stringify(S.getState(), (k, v) => (typeof v === 'function' ? undefined : v)));
function reset() { S.setState(JSON.parse(JSON.stringify(init)), false); }

function runCase(answers, sens, pain, flow, mood, energy) {
  reset();
  S.getState().completeAssessment(answers);
  if (sens) S.getState().updateFineTuningSettings({ strainSensitivity: sens });
  S.setState({ symptomLogs: [{ id: 'x', date: '2026-11-01', timestamp: '2026-11-01T08:00:00Z', pain, flow, mood, energy }] });
  const t0 = process.hrtime.bigint();
  S.getState().fineTuneAllAnalytics();
  const dt = Number(process.hrtime.bigint() - t0) / 1000; // microseconds
  const st = S.getState();
  const b = st.biometrics;
  const an = st.clinicalReport.anomalies;
  return {
    archetype: st.fineTuningSettings.archetypeName, sens: st.fineTuningSettings.strainSensitivity,
    strain: b.strainScore, level: b.strainLevel, cortisol: b.cortisol.level, override: b.cortisol.isOverride,
    sleepDeficit: b.sleep.deficit, hrvDelta: b.hrv.delta, nAnom: an.length,
    nCritical: an.filter((a) => a.severity === 'critical').length, nSevere: an.filter((a) => a.severity === 'severe').length,
    dt,
  };
}

const rows = [];
for (const [pname, ans] of Object.entries(PROFILES))
  for (const sens of SENS)
    for (let pain = 0; pain <= 10; pain++)
      for (const flow of FLOWS)
        for (let mood = 1; mood <= 5; mood++)
          for (const energy of ENERGY) {
            const r = runCase(ans, sens, pain, flow, mood, energy);
            rows.push({ profile: pname, pain, flow, mood, energy, ...r });
          }

// ---- summaries
const N = rows.length;
const pct = (f) => (100 * rows.filter(f).length) / N;
const levels = {};
for (const r of rows) levels[r.level] = (levels[r.level] || 0) + 1;
const strains = rows.map((r) => r.strain).sort((a, b) => a - b);
const q = (p) => strains[Math.min(N - 1, Math.floor(p * N))];

// override cause attribution (first matching clause of the deployed rule)
const cause = { 'strain>=65': 0, 'pain>=7': 0, 'mood<=2': 0, 'strain>=40': 0, 'pain>=5': 0 };
for (const r of rows) {
  if (!r.override) continue;
  if (r.strain >= 65) cause['strain>=65']++; else if (r.pain >= 7) cause['pain>=7']++; else if (r.mood <= 2) cause['mood<=2']++;
  else if (r.strain >= 40) cause['strain>=40']++; else if (r.pain >= 5) cause['pain>=5']++;
}

// monotonicity checks
const key = (r) => [r.profile, r.sens, r.pain, r.flow, r.mood, r.energy].join('|');
const idx = new Map(rows.map((r) => [key(r), r]));
let painViol = 0, painPairs = 0, flowViol = 0, flowPairs = 0, moodViol = 0, moodPairs = 0;
const flowViolPairs = {};
for (const r of rows) {
  if (r.pain < 10) { const n = idx.get(key({ ...r, pain: r.pain + 1 })); painPairs++; if (n.strain < r.strain) painViol++; }
  const fi = FLOWS.indexOf(r.flow);
  if (fi < FLOWS.length - 1) { const n = idx.get(key({ ...r, flow: FLOWS[fi + 1] })); flowPairs++; if (n.strain < r.strain) { flowViol++; const k = r.flow + '->' + FLOWS[fi + 1]; flowViolPairs[k] = (flowViolPairs[k] || 0) + 1; } }
  if (r.mood < 5) { const n = idx.get(key({ ...r, mood: r.mood + 1 })); moodPairs++; if (n.strain > r.strain) moodViol++; }
}

// level-threshold consistency: fineTune (36/60/80) vs setStrainScore (38/62/82)
const lvlSet = (s) => (s >= 82 ? 'severe' : s >= 62 ? 'high' : s >= 38 ? 'moderate' : 'low');
const lvlMismatch = rows.filter((r) => lvlSet(r.strain) !== r.level).length;

// per-profile summaries
const byProfile = {};
for (const p of Object.keys(PROFILES)) {
  const rr = rows.filter((r) => r.profile === p);
  byProfile[p] = {
    archetype: rr[0].archetype,
    meanStrain: rr.reduce((a, r) => a + r.strain, 0) / rr.length,
    overridePct: (100 * rr.filter((r) => r.override).length) / rr.length,
    meanAnom: rr.reduce((a, r) => a + r.nAnom, 0) / rr.length,
    criticalPct: (100 * rr.filter((r) => r.nCritical > 0).length) / rr.length,
  };
}

// latency of the real functions
const dts = rows.map((r) => r.dt).sort((a, b) => a - b);
const cyc = [{ id: 'a', cycleNumber: 1, daysAgo: 10, lengthDays: 31, periodDurationDays: 5 }, { id: 'b', cycleNumber: 2, lengthDays: 29, periodDurationDays: 5 }, { id: 'c', cycleNumber: 3, lengthDays: 35, periodDurationDays: 5 }];
for (let i = 0; i < 2000; i++) m.calculateCyclePredictionAndPrecautions(3, cyc, {}, 4, 'none');
const K = 50000; const c0 = process.hrtime.bigint();
for (let i = 0; i < K; i++) m.calculateCyclePredictionAndPrecautions(3, cyc, { q1: 'q1_opt1' }, 4, 'none');
const cycUs = Number(process.hrtime.bigint() - c0) / 1000 / K;

// scenario personas (one daily log each) for the functional table
const personas = [
  ['P1 Low-risk, mild day', 'Low-risk type', 2, 'light', 4, 'high'],
  ['P2 PCOS-type, spotting', 'PCOS-type', 4, 'spotting', 3, 'moderate'],
  ['P3 PMDD-type, late-luteal low mood', 'PMDD-type', 5, 'none', 1, 'low'],
  ['P4 High-stress, heavy flow', 'High-stress type', 7, 'heavy', 2, 'low'],
  ['P5 Severe dysmenorrhoea', 'Low-risk type', 9, 'severe', 3, 'restorative'],
].map(([name, prof, pain, flow, mood, energy]) => {
  const r = runCase(PROFILES[prof], null, pain, flow, mood, energy);
  return { name, prof, pain, flow, mood, energy, archetype: r.archetype, sens: r.sens, strain: r.strain, level: r.level, cortisol: r.cortisol, override: r.override, nAnom: r.nAnom, nCritical: r.nCritical, nSevere: r.nSevere };
});

const out = {
  N, strainMin: strains[0], strainMax: strains[N - 1], p25: q(0.25), median: q(0.5), p75: q(0.75),
  levels, overridePct: pct((r) => r.override), cortisolHighPct: pct((r) => r.cortisol === 'high'),
  sleepDeficitPct: pct((r) => r.sleepDeficit), cause,
  mono: { painPairs, painViol, flowPairs, flowViol, flowViolPairs, moodPairs, moodViol },
  lvlMismatch, lvlMismatchPct: (100 * lvlMismatch) / N, byProfile,
  latency: { fineTuneMeanUs: dts.reduce((a, b) => a + b, 0) / N, fineTuneP95Us: dts[Math.floor(0.95 * N)], cyclePredMeanUs: cycUs },
  personas, node: process.version,
};
fs.writeFileSync('results_b.json', JSON.stringify(out, null, 1));
fs.writeFileSync('sweep_b.json', JSON.stringify(rows.map(({ dt, ...r }) => r)));
console.log(JSON.stringify(out, null, 1));
